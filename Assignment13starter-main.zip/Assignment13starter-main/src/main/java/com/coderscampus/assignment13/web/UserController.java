package com.coderscampus.assignment13.web;

import java.util.Arrays;
import java.util.Set;

import com.coderscampus.assignment13.domain.Account;
import com.coderscampus.assignment13.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.coderscampus.assignment13.domain.User;
import com.coderscampus.assignment13.domain.Address;
import com.coderscampus.assignment13.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private AccountRepository accountRepo;

	@GetMapping("/users")
	public String getAllUsers(ModelMap model) {
		Set<User> users = userService.findAll();

		model.put("users", users);
		if (users.size() == 1) {
			model.put("user", users.iterator().next());
		}

		return "users";
	}

	@GetMapping("/users/{userId}")
	public String getOneUser(ModelMap model, @PathVariable Long userId) {
		User user = userService.findById(userId);
		model.put("users", Arrays.asList(user));
		model.put("user", user);
		return "users";
	}

	@PostMapping("/users/{userId}")
	public String postOneUser(@ModelAttribute User user, ModelMap model) {
		User existingUser = userService.findById(user.getUserId());
		existingUser.setUsername(user.getUsername());
		existingUser.setPassword(user.getPassword());
		existingUser.setName(user.getName());

		// Update or create the address if it's not null
		if (user.getAddress() != null) {
			Address existingAddress = existingUser.getAddress();
			if (existingAddress == null) {
				Address newAddress = user.getAddress();
				newAddress.setUser(existingUser); // Set the user property in address
				existingUser.setAddress(newAddress);
			} else {
				existingAddress.setAddressLine1(user.getAddress().getAddressLine1());
				existingAddress.setAddressLine2(user.getAddress().getAddressLine2());
				existingAddress.setCity(user.getAddress().getCity());
				existingAddress.setRegion(user.getAddress().getRegion());
				existingAddress.setCountry(user.getAddress().getCountry());
				existingAddress.setZipCode(user.getAddress().getZipCode());
			}
		}

		// Preserve existing accounts
		for (Account account : user.getAccounts()) {
			if (!existingUser.getAccounts().contains(account)) {
				existingUser.getAccounts().add(account);
			}
		}

		userService.saveUser(existingUser);
		return "redirect:/users/" + user.getUserId();  // Redirect to the updated user's page
	}

	@PostMapping("/users/{userId}/delete")
	public String deleteOneUser(@PathVariable Long userId) {
		userService.delete(userId);
		return "redirect:/users";
	}

	@GetMapping("/register")
	public String getCreateUser(ModelMap model) {
		model.put("user", new User());
		return "register";
	}

	@PostMapping("/register")
	public String postCreateUser(User user) {
		System.out.println(user);
		userService.saveUser(user);
		return "redirect:/register";
	}
	@PostMapping("/users/{userId}/accounts")
	public String createNewBankAccount(@PathVariable Long userId) {
		User user = userService.findById(userId);
		Account newAccount = new Account();
		newAccount.setAccountName("New Account");
		newAccount.getUsers().add(user);

		// Save the new account first
		accountRepo.save(newAccount);

		user.getAccounts().add(newAccount);
		userService.saveUser(user); // Save the user with the new account association

		return "redirect:/users/" + userId + "/account/" + newAccount.getAccountId();
	}

	@GetMapping("/users/{userId}/account/{accountId}")
	public String getAccount(ModelMap model, @PathVariable Long userId, @PathVariable Long accountId) {
		User user = userService.findById(userId);
		Account account = user.getAccounts().stream()
				.filter(acc -> acc.getAccountId().equals(accountId))
				.findFirst()
				.orElseThrow(() -> new IllegalArgumentException("Invalid account Id:" + accountId));
		model.put("user", user);
		model.put("account", account);
		return "account";
	}

	@PostMapping("/users/{userId}/account/{accountId}")
	public String updateAccount(@ModelAttribute Account account, @PathVariable Long userId, @PathVariable Long accountId) {
		User user = userService.findById(userId);
		Account existingAccount = user.getAccounts().stream()
				.filter(acc -> acc.getAccountId().equals(accountId))
				.findFirst()
				.orElseThrow(() -> new IllegalArgumentException("Invalid account Id:" + accountId));
		existingAccount.setAccountName(account.getAccountName());
		userService.saveUser(user);
		return "redirect:/users/" + userId;
	}
}
