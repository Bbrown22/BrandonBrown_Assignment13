# Assignment 13 starter

To use this template:

- Click on the green `Use this template` button.

- Name your new project `Assignment13` or whatever convention you use to name your assignment projects.

- This will create a repository on github for your assignment. Clone this remote repository down to your local computer, as you would clone any other repository. Place it on your computer in the same folder as your other coderscampus assignments.

- Import into Eclipse or open with VSCode or IntelliJ as you would any other Spring boot maven project.

__You now have the starting code for Assignment 13. Follow instructions in the assignment definition to complete this project.__
